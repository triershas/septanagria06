<?php
session_start();
include ('../koneksi/koneksi.php');
$username = htmlspecialchars($_POST ['username']);
$password = htmlspecialchars(md5($_POST ['password']));

if(empty ($username) || empty($password)) {
echo "<script>alert('Username atau Password tidak boleh kosong')</script>";
echo "<meta http-equiv='refresh' content='1 url=login.php'>";
}else {

$sql = $koneksi->query("select * from users where username='$username' and password='$password'");
$data = mysqli_fetch_array($sql);

//mengecek jumlah baris untuk hasil query
$cek = mysqli_num_rows($sql);

if($cek >0) {
$_SESSION['id_user'] = $data['id_user'];
$_SESSION['status_login'] = "1";
header ('location:../admin/tampil_profil.php');
exit();
}else {
echo "<script>alert('Anda belum terdaftar')</script>";
echo "<meta http-equiv='refresh' content='1 url=login.php'>";
}
}
?>