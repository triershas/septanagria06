<?php
include ('../tema/header_admin.php');
include ('../tema/sidebar_admin.php');
?>

<html>
<head>
<title>Add Acount</title>
</head>
<body>
<div class="content-wrapper">
<section class="content">
<div class="row">
<div class="col-xs-12">
<form method="POST" name="pendaftaran" action="proses_daftar.php">
<table border="0" align="center" cellspacing=0>
<tr>
<td colspan="3"><center><font size=5>PENDAFTARAN</font></center></td>
</tr>
<tr>
<td>Nama</td><td>:</td><td><input type="text" name="nama"></td>
</tr>
<tr>
<td>Email</td><td>:</td><td><input type="text" name="email"></td>
</tr>
<tr>
<td>Username</td><td>:</td><td><input type="text" name="username"></td>
</tr>
<tr>
<td>Password</td><td>:</td><td><input type="password" name="password"></td>
</tr>
<tr>
<td colspan=2>&nbsp;</td>
<td><input type="submit" value="Daftar"></td>
</tr>
<tr>
<td colspan=3><a href="login.php">LOGIN</a></td>
</tr>
</table>
</form>
</div>
</div>
</section>
</div>
</body>
</html>

<?php
include ('../tema/footer_admin.php');
?>