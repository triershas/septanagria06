<?php 
include ('../koneksi/koneksi.php');
$nama = htmlspecialchars($_POST['nama']);
$email = htmlspecialchars($_POST['email']);
$username = htmlspecialchars($_POST['username']);
$password = htmlspecialchars(md5($_POST['password']));


//CEK INPUTAN
if(empty($nama) || empty ($email) || empty ($username) || empty ($password)) {
echo "<script>alert('Inputan tidak boleh kosong')</script>";
echo "<meta http-equiv='refresh' content='1 url=daftar.php'>";
}else {
$koneksi->query("Insert into users(nama,email,username,password) values('$nama','$email','$username','$password')");

}
?>