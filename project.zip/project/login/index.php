<?php
include("../koneksi/koneksi.php");
header ("location : ../admin/tampil_profil.php");
?>