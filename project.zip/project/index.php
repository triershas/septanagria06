	 <?php
      include ('tema/header.php');
      include ('tema/sidebar.php');
	?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-xs-12">
            
            	<?php
            		include ('koneksi/koneksi.php');
            		$apa = mysqli_query($koneksi, "select*from profil");
            		while($adi=mysqli_fetch_array($apa)) {
            	?>
      		    	<div class="box">
                  <div class="box-header with-border">
                    <h3 class="box-title">	<?php echo $adi['judul_profil'];?> <br></h3>
                  </div>
                  <div class="box-body">
      				      <?php echo substr ($adi['isi_profil'],0,250);?>...... <br>
                  </div><!-- /.box-body -->
                  <div class="box-footer">
      				      <a href="profil.php?no=<?php echo $adi['no_profil'];?>">baca selengkapnya </a> <hr>
                  </div><!-- /.box-footer-->
                </div>
            	<?php
            	};
            	?>
              </div><!-- /.box -->
          </div><!-- /.row (main row) -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      
      <?php
      include ('tema/footer.php');
      ?>