-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 07, 2018 at 12:43 
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `artikel`
--

CREATE TABLE `artikel` (
  `no_artikel` int(11) NOT NULL,
  `judul_artikel` mediumtext,
  `isi_artikel` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `artikel`
--

INSERT INTO `artikel` (`no_artikel`, `judul_artikel`, `isi_artikel`) VALUES
(0, 'ARTIKEL 1', 'ISI 1'),
(2, 'ARTIKEL 2', 'ISI 2'),
(3, 'ARTIKEL 3', 'ISI 3');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `no_berita` int(11) NOT NULL,
  `judul_berita` mediumtext,
  `isi_berita` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`no_berita`, `judul_berita`, `isi_berita`) VALUES
(1, 'BERITA 1', 'ISI 1'),
(2, 'BERITA 2', 'ISI 2'),
(3, 'BERITA 3', 'ISI 3');

-- --------------------------------------------------------

--
-- Table structure for table `profil`
--

CREATE TABLE `profil` (
  `no_profil` int(10) NOT NULL,
  `judul_profil` varchar(100) NOT NULL,
  `isi_profil` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profil`
--

INSERT INTO `profil` (`no_profil`, `judul_profil`, `isi_profil`) VALUES
(17, 'Visi Desa Rakitan', '<p>Terwujudnya desa Rakitan yang mandiri, berkualitas, damai, aman, dan sejahtera berlandaskan Iman dan Taqwa berdasarkan Pancasila</p>\r\n\r\n<p>&nbsp;</p>\r\n'),
(18, 'Misi Desa Rakitan', '<p>1. Menyelenggarakan pemerintah yang efisien, efektif,dan bersih serta transparan dengan mengutamakan pelayanan kepada masyarakat.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>2. Meningkatkan dan menggali sumber pendapatan desa dan investasi pembangunan.</p>\r\n\r\n<p>3. Mengembangkan pemberdayaan lembaga desa dan masyarakat serta kemitraan dalam melaksanakan pembangunan.</p>\r\n\r\n<p>4. Meningkatkan kualitas sumber saya manusia dalam pembangunan desa yang berkelanjutan.</p>\r\n\r\n<p>5. Mempertahankan prestasi dan nama baik desa di tingkat daerah maupun nasional serta berusaha meningkatkan.</p>\r\n\r\n<p>6. Mengembangkan dan meningkatkan pertumbuhan dan perekonomian kerakyatan guna mengurangi kemiskinan.</p>\r\n\r\n<p>7. Menciptakan rasa aman dan tentram dalam suasana kehidupan yang demokratis dan agamis.</p>\r\n'),
(19, 'Strategi dan Arah Kebijakan Desa Rakitan', '<p>1.Menjalankan roda pemerintahan,pembangunan dan kemasyarakatan sesuai Visi &amp; Misi.</p>\r\n\r\n<p>2.Memperdayakan masyarakat dan Lembaga Desa yang ada dalam pelaksanaan pembangunan.</p>\r\n\r\n<p>3.Efisiensi anggaran serta mencari peluang sumber pendapatn baru yang belum tergali.</p>\r\n\r\n<p>4.Mengoptimalkan kinerja Perangkat Desa dalam melayani masyarakat secara ramah,cepat,tepat mudah dan murah guna memsukseska Rencana Kerja Pembangunan Desa.</p>\r\n\r\n<p>5.Mendukung Program Kabupaten Banjarnegara tahun 2011-2016 sesuai Visi Kabupaten Banjarengara yaitu Banjarengara Yang Mandiri Berdaya Saing Menuju Masyarakat Sejahtera Yang Berakhlak Mulia Berbasis Pertanian.</p>\r\n'),
(20, 'Prioritas Desa Rakitan', '<p>Pembangunan secara adil dan merata berdasarkan skala Prioritas di masing-masing bidang seperti Pendidikan,Ekonomi Kerakyatan,Kesehatan,Infrastruktur Pertanian Dan Pemerintahan.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n'),
(21, 'Sejarah Desa Rakitan', '<p>Konon pada tahun 1825 terjadilah peperangan antara laskar diponegoro melawan Belanda. Peperangan tersebut terjadi di Watu Lembu, Banjarkulon. Dua prajurit dari laskar diponegoro melarikan diri karena terdesak, mereka adalah Ki Bogo dan Ny. Nyiskati atau gelarnya Ny. Ageng Rakit. Mereka lari kearah sungai merawu, dan dalam perjalanan Ki Bogo menancapkan tongkatnya di wilayah pohon jati. Pohon jati ini pun menjadi bukti bahwa mereka telah melakukan perjalanan karna lari dari peperangan. Mereka pun melanjutkan perjalanan sampai akhirnya menemukan tempat persinggahan yakni watu payung dimana terdapat batu yang besar dan dibawahnya terdapat gua. Setelah itu mereka melanjutkan perjalanan unuk lari kearah hulu dan menemukan sungai kecil yang arus airnya terbalik dan sungai itu dinamakan walik watang, walik yaitu terbalik sedangkan watang merupakan saluran.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Ki Bogo dan Ny. Nyiskati terus berjalan menelusuri sungai merawu sampai akhirnya menemukan daerah dimana disana terdapat pohon pocung yang buahnya enak dimakan tanpa dimasak terlebih dahulu. Akhirnya daerah itu dinamakan desa pocungsari. Berjalan pelan menuju arah barat wilayah pocung, mereka berhenti disuatu daerah. Namun Ny. Nyisketi tidak mau menetap didaerah tersebut melainkan melanjutkan perjalanan. Akhirnya hanya Ki Bogo saja yang menetap di daerah tersebut. Maka daerah ini dinamakan desa bogoan diambil dari nama Ki Bogo.</p>\r\n\r\n<p>Ketidakmauan Ny. Nyisketi untuk tetap tinggal bersama Ki Bogo, akhirnya Ny. Nyisketi melanjutkan perjalanan kearah tenggara arah bawah. Disana beliau berhenti di suatu daerah yang sepi tidak ada satu pun manusia yang tinggal, sampai binatang pun tidak ada yang berkeliaran. Suasananya yang sunyi dan menyeramkan ini tidak membuat Ny. Nyisketi berhenti untuk menetap bahkan beliau memberikan nama daerah itu menjadi desa jambon yang artinya lembah indah yang sepi. Karena beliau tidak mau menetap disana, Ny. Nyisketi justru kembali ke arah bogoan. Kabut yang sangat tebal mengakibatkan Ny. Nyisketi berjalan kearah kiri ketempat yang landai, dan tempat ini seperti karangan yang belum jadi dan dikelung-kelung. Akhirnya tempat ini dinamakan desa karang talun yang artinya karangan yang dikelung-kelung. Ny. Nyisketi belum merasa puas atau tidak mau menetap didesa karang talun, beliau terus melanjutkan perjalanan sampai bisa menetap.</p>\r\n\r\n<p>Setelah menelusuri daerah-daerah yang telah dilalui oleh Ny. Nyisketi dan memberikan nama daerah tersebut, beliau masih melanjutkan perjalanan ke arah barat. Sampai akhirnya beliau mendapatkan daerah yang cocok untuk tinggal dan bermukim. Ny. Nyisketi pun sudah merasa nyaman dan tidak mau melanjutkan perjalanan lagi untuk mendapatkan tempat yang cocok untuk tinggal dan aman dari serangan Belanda. Akhirnya daerah tersebut beliau menamakan desa rakitan. Dimana kata rakit diambil dari gelarnya yaitu Ny. Ageng Rakit. Dan pada tahun 1850 desa Rakitan telah didirikan secara resmi.</p>\r\n'),
(22, 'Letak Desa Rakitan', '<p>Desa Rakitan ini terletak di Kecamatan Madukara Kabupaten Banjarnegara Provinsi Jawa tengah.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Desa Rakitan ini terbentuk dan berdiri pada tahun 1858</p>\r\n\r\n<p>Desa Rakitan ini memiliki koordinat yaitu 109.7048 LS/LU -7.360704 BT/BB</p>\r\n\r\n<p>Dan Desa Rakitan berbatasan langsung dengan desa-desa yaitu</p>\r\n\r\n<p>disebelah utara berbatasan langsung dengan Desa Kaliurip,Kecamatan Madukara</p>\r\n\r\n<p>di sebelah selatan berbatasan langsung Desa Petambakan,Kecamatan Madukara</p>\r\n\r\n<p>di sebelahtimur berbatasan langsung dengan Desa Blitar dan Desa Sered,Kecamatan Madukara</p>\r\n\r\n<p>di sebelah barat berbatasan langsung dengan Desa Banjarmangu,Kecamatan Banjarmangu</p>\r\n'),
(23, 'Lembaga Kemasyarakatan Desa Rakitan', '<p><strong>LPMD/LPMK ATAU SEBUTAN LAIN</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Jumlah = 1</p>\r\n\r\n<p>Dasar hukum pembentukan = Belum ada LKD/LKK atau belum ada dasar hukum</p>\r\n\r\n<p>Jumlah pengurus = 6 orang</p>\r\n\r\n<p>Ruang lingkup kegiatan = 1 Jenis</p>\r\n\r\n<p><strong>PKK</strong></p>\r\n\r\n<p>Jumlah = 1</p>\r\n\r\n<p>Dasar Hukum Pembentukan = Belum ada LKD/LKK atau Belum ada dasar hukum</p>\r\n\r\n<p>Jumlah Pengurus = 10 Orang</p>\r\n\r\n<p>Alamat Kantor = KANTOR DESA RAKITAN</p>\r\n\r\n<p>Ruang Lingkup Kegiatan = 4 Jenis</p>\r\n\r\n<p><strong>RUKUN WARGA</strong></p>\r\n\r\n<p>Jumlah = 3</p>\r\n\r\n<p>Dasar Hukum Pembentukan = Belum ada LKD/LKK atau belum ada dasar hukum</p>\r\n\r\n<p>Jumlah Pengurus = 3 Orang</p>\r\n\r\n<p>Alamat Kantor = Kantor Desa Rakitan</p>\r\n\r\n<p>Ruang Lingkup Kegiatan =4 Jenis</p>\r\n\r\n<p><strong>RUKUN TETANGGA</strong></p>\r\n\r\n<p>Jumlah = 18</p>\r\n\r\n<p>Dasar Hukum Pembentukan = Belum ada LKD/LKK atau belum ada dasar hukum</p>\r\n\r\n<p>Jumlah Pengurus = 108 Orang</p>\r\n\r\n<p>Alamat Kantor = di RT masing-masing</p>\r\n\r\n<p>Ruang Lingkup Kegiatan =5 Jenis</p>\r\n\r\n<p><strong>KELOMPOK TANI/NELAYAN</strong></p>\r\n\r\n<p>Jumlah = 5</p>\r\n\r\n<p>Dasar Hukum Pembentukan = Belum ada LKD/LKK atau Belum ada dasar hukum</p>\r\n\r\n<p>Jumlah Pengurus = 40 Orang</p>\r\n\r\n<p>Alamat Kantor = Di rumah masing-masing ketua kelompok tani</p>\r\n\r\n<p>Ruang Lingkup Kegiatan = 3 Jenis</p>\r\n\r\n<p><strong>BADAN USAHA MILIK DESA</strong></p>\r\n\r\n<p>Jumlah = 1</p>\r\n\r\n<p>Dasar Hukum Pembentukan = Belum ada LKD/LKK atau Belum ada dasar hukum</p>\r\n\r\n<p>Jumlah Pengurus = 4 Orang</p>\r\n\r\n<p>Alamat Kantor = Kantor Desa rakitan</p>\r\n\r\n<p>Ruang Lingkup Kegiatan = 2 Jenis</p>\r\n'),
(24, 'jukhkjuhnjuhnkihn', '<p>jhgbjyhgukjhi</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `username`, `password`) VALUES
(3, 'eni', 'eni@gmail.com', 'eni', '47bce5c74f589f4867dbd57e9ca9f808'),
(5, 'enifadlilah', 'enifadlilah18@gmail.com', 'enifadlilah', 'c128e58f848b234123b82ac2670ab98b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`no_artikel`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`no_berita`);

--
-- Indexes for table `profil`
--
ALTER TABLE `profil`
  ADD PRIMARY KEY (`no_profil`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profil`
--
ALTER TABLE `profil`
  MODIFY `no_profil` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
