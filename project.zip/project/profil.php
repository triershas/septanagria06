	 <?php
      include ('tema/header.php');
      include ('tema/sidebar.php');
	?>
<div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <?php
  				$no = $_GET ['no'];
          include ('koneksi/koneksi.php');
  				$apa = mysqli_query($koneksi, "select*from profil where no_profil = '$no'");
  				$adi=mysqli_fetch_array($apa);
  			?>
        <div class="box">
          <div class="box-header with-border">
            <h3 class="box-title">
            <?php echo $adi['judul_profil'];?><br></h3>
          </div>
          <div class="box-body">
            <?php echo $adi['isi_profil'];?><br>
          </div><!-- /.box-body -->
        </div>            
      </div>
    </div>
  </section>
</div>
      <?php
      include ('tema/footer.php');
      ?>



      
      
