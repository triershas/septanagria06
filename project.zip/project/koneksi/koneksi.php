<?php
$host="localhost";
$user="root";
$pass="";
$db="login";

$koneksi = mysqli_connect($host, $user, $pass, $db);

//mysql_select_db($db, $koneksi);

?>
