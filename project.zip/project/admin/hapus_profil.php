<?php
include "../koneksi/koneksi.php";

$id=$_GET['no'];
$hapus=mysqli_query($koneksi, "delete from profil WHERE no_profil='$id'");
if ($hapus){
header("location:tampil_profil.php");
}
?>