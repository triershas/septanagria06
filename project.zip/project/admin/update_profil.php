<?php
include "../koneksi/koneksi.php";
$id=$_GET['no'];
$judul=$_GET['judul'];
$isi=$_GET['isi'];

$a= mysqli_query($koneksi, "update profil set judul_profil='$judul',isi_profil='$isi' WHERE no_profil='$id'");
if ($a){
header ('location:tampil_profil.php');
}
?>