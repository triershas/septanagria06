<?php
include ("../tema/header_admin.php");
include ("../tema/sidebar_admin.php");
include ("../tema/footer_admin.php");
?>