<?php
session_start();
@$iduser = $_SESSION['id_user'];
@$ceklogin = $_SESSION['status_login'];

if($ceklogin ==1) {

include ('../koneksi/koneksi.php');
include ('../tema/header_admin.php');
include ('../tema/sidebar_admin.php');
?>

<script type="text/javascript" src="../ckeditor/ckeditor.js"></script>
	<div class="content-wrapper">
		<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<form action="proses.php" method="POST">
					<div class="form-group">
						<table>Judul</table> <input type="text" class="form-control" name="judul_profil">
					</div><br/><br>
					<div class="form-group">
						<table> Isi </table> <textarea class="form-control ckeditor" name="isi_profil" class="form-control" rows="10"></textarea><br/>
					</div>
					<input type="submit" value="Simpan" class="btn btn-danger"><br>
				</form>
			</div>
		</div>
		</section>
	</div>

<?php
include ('../tema/footer_admin.php');
}else {
echo "<script>alert ('Anda Belum login atau Anda Bukan Admin')</script>";
echo "<meta http-equiv='refresh' content='1 url=../login/login.php'>";
}
?>