<?php
session_start();
@$iduser = $_SESSION['id_user'];
@$ceklogin = $_SESSION['status_login'];

if($ceklogin ==1) {

include ('../koneksi/koneksi.php');
include ('../tema/header_admin.php');
include ('../tema/sidebar_admin.php');

?>			
<div class="content-wrapper">
<section class="content">
<div class="row">
<div class="col-xs-12">
<h3><a href="input.php">Tambah Data</a></h3>
	<div class="box">
		<div class="box-header">
     	</div><!-- /.box-header -->
      	<div class="box-body no-padding">
      		<table class="table table-striped">
            	<tbody>
					<?php
					$apa = mysqli_query($koneksi, "select*from profil");
					while($adi=mysqli_fetch_array($apa)) {
					?>
					<tr>
			    		<td> <?php echo $adi['no_profil']; ?></td>
			          	<td><?php echo $adi['judul_profil']; ?></td>
			          	<td><a href="edit_profil.php?no=<?php echo $adi['no_profil'];?>">Edit </a> &nbsp;
							<a href="hapus_profil.php?no=<?php echo $adi['no_profil'];?>">Hapus </a></td>
			        </tr>
					<?php
					};
					?>
				</tbody>
			</table> 
		</div><!-- /.box-body -->
	</div>
</div>
</div>
</section>
</div>
<?php
include ('../tema/footer_admin.php');
}else {
echo "<script>alert ('Anda Belum login atau Anda Bukan Admin')</script>";
echo "<meta http-equiv='refresh' content='1 url=../login/login.php'>";
}
?>