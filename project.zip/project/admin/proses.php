<?php
include ('../koneksi/koneksi.php');
$judul=$_POST['judul_profil'];
$pass=$_POST['isi_profil'];

$ada= mysqli_query($koneksi, "INSERT INTO profil(judul_profil,isi_profil)values ('$judul','$pass')");

if ($ada){
echo "sukses";
header('location:tampil_profil.php');
}else{ echo "gagal";
}

?>
